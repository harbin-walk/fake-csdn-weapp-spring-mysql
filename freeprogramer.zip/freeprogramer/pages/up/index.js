// pages/up/index.js
const app=getApp();
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    headtext:'选择分类',
    open:true,
    height:700,
    con: [{
      id: 0,
      name: 'code',
      checked: false
    },
    {
      id: 1,
      name: '计算机基础',
      checked: false
    },
    {
      id: 2,
      name: '前端',
      checked: false
    },
    {
      id: 3,
      name: 'java',
      checked: false
    },
    {
      id: 4,
      name: 'java框架',
      checked: false
    },
    {
      id: 5,
      name: '数据库',
      checked: false
    },
    {
      id: 6,
      name: 'C语言',
      checked: false
    },
    {
      id: 7,
      name: 'C++',
      checked: false
    },
    {
      id: 8,
      name: 'sql编程',
      checked: false
    }
  ],
  },
  islength(e){
    if(e.detail.cursor>10){
      wx.showToast({
        title: '标题过长',
        icon:'none',
      })
    }
  },

  changeradio:function(e){

    var con=this.data.con;
    for(var i=0;i<9;++i)
      con[i].checked=false;
    con[e.detail.value].checked=true;
    this.setData({
      con:con

    })
  },

  closefenlei:function(e){
    if(this.data.open==true)
    wx.showToast({
      title: '点击最下方可以呼出分类',
      icon:'none'
    })
    this.setData({
      open:false

    })

  },
  openfenlei:function(e){
    
    this.setData({
      open:true
    })
  },

  upcontent:function(e){
    //上传的分类
      var t='';
      for(var i=0;i<9;++i){
        if(this.data.con[i].checked==true){
          t=this.data.con[i].id;
          break;
        }
      }
      console.log(t);

      var title=e.detail.value.title;
      var content=e.detail.value.content;
      if(title.length>10){
        wx.showToast({
          title: '标题过长',
          icon:'none'
        })
        return ;
      }
      if(title.length<=0){
        wx.showToast({
          title: '标题为空',
          icon:'none',
        });
        return ;
      }else if(content.length<=0){
        wx.showToast({
          title: '内容为空',
          icon:'none',
        });
        return ;
      }else {
        //后端发起请求
        wx.request({
          url:  app.globalData.requesturl+'content/up',
          method:'POST',
          header:{
            'content-type': 'application/x-www-form-urlencoded;charset=utf-8'
          },
          data:{
            databaseindex:t,
            user_id:app.globalData.openId,
            title:title,
            content:content

          },
          success:function(res){
            wx.showToast({
              title: '提交成功',
            })
            wx.navigateBack({
              delta:1
            })

          },
            fail:function(res){
              wx.showToast({
                title: '提交失败,请检查网络',
              })
            }

        })
      }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that =this;
    var temp=wx.getSystemInfoSync().windowHeight*0.9;
    that.setData({
      height:temp,
      
    });
    
    console.log(this.data.height);
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})