// pages/study/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //srcroll的高度
    srcollhight: 700,

    cardindex: -1,
    //分类
    swipers: [{
      name: '推荐',
      index: 10
    }, {
      name: 'code',
      index: 0
    }, {
      name: '计算机基础',
      index: 1
    }, {
      name: '前端',
      index: 2
    }, {
      name: 'java',
      index: 3
    }],
    //选择的分类下标
    currentindex: 0,
    //卡片内容
    content: [],

    datanums: 0,
    //储存下标和分类之间的关系
    database: [{
        name: "code",
        index: 0
      }, {
        name: "计算机基础",
        index: 1
      }, {
        name: "前端",
        index: 2
      },
      {
        name: "java",
        index: 3
      }, {
        name: "java框架",
        index: 4
      }, {
        name: "数据库",
        index: 5
      },
      {
        name: "c语言",
        index: 6
      }, {
        name: "c++",
        index: 7
      }, {
        name: "数据库编程",
        index: 8
      }

    ],
    //推荐分类的内容
    content0:[]
  },
  //动态设置scroll的高度
  calcheight: function () {
    console.log(wx.getSystemInfoSync().windowHeight);
    let that = this;

    let query = wx.createSelectorQuery().in(this);
    query.select(".header").boundingClientRect();
    query.select(".contentlist").boundingClientRect();

    query.exec(res => {
        let headerheight = res[0].height;
        console.log(headerheight);
        let contentlistheight = res[1].height;
        console.log(contentlistheight);
        let srcollhight = wx.getSystemInfoSync().windowHeight - headerheight - contentlistheight;
        that.setData({
          srcollhight: srcollhight,
        })
      }



    )
  },
  //单击卡片 内容
  tapcard: function (e) {
    var that = this;
    console.log(e.currentTarget.dataset.cardinfo);
    var index = e.currentTarget.dataset.cardinfo;
    this.setData({
      cardindex: index,
    })
    var con;
    if(that.data.currentindex==0)
      con=that.data.content0;
      else
      con=that.data.content;
    wx.navigateTo({
      url: '../cardcontent/index',
      success: function (res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', {
          data: con[index]
        })
      }
    })
  },

  //搜索
  serch: function (e) {



  },
  //选择分类
  chosecontent: function (e) {
    var that = this;
    this.setData({
      currentindex: e.currentTarget.dataset.index,
    });
    console.log(this.data.currentindex);
    //获取分类里的数据
   that.updata();

  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.request({
      url: app.globalData.requesturl+'content/getdefaulthot',
      header: {
        'content-type': 'application/json'

      },
      success:function(res){
        that.setData({
          content0:res.data
        })
      }
    })

    wx.login({
      success: function (res) {
        console.log("login")
        console.log(app.globalData)
        app.globalData.code = res.code; //登录凭证

      }
    })
    if (app.globalData.code != null) {
      //2、调用获取用户信息接口
      // 查看是否授权

      // 获取用户信息
      wx.getSetting({
        success: res => {
          if (res.authSetting['scope.userInfo']) {
            // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
            wx.getUserInfo({
              success: res => {
                // 可以将 res 发送给后台解码出 unionId
                wx.request({
                  url: app.globalData.requesturl + 'login/getopenid', //自己的服务接口地址
                  method: 'get',
                  header: {
                    "Content-Type": "applqciation/json"
                  },
                  data: {
                    encryptedData: res.encryptedData,
                    iv: res.iv,
                    code: app.globalData.code
                  },
                  success: function (res) {
                    console.log(res)
                    console.log("已经授权，获得openid=" + res.data)
                    app.globalData.openId = res.data

                  }
                })
                app.globalData.userInfo = res.userInfo;
                console.log(res.userInfo);
                // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
                // 所以此处加入 callback 以防止这种情况
                if (app.userInfoReadyCallback) {
                  app.userInfoReadyCallback(res)
                }
              }
            })
          }
        }
      })

    }
  

  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    let that = this;

    that.calcheight();

  },

  //更换scroll里面的内容
  updata:function(){
    var that=this;
    if(that.data.currentindex!=0){
      wx.request({
        url: app.globalData.requesturl + 'content/get',
        method: 'get',
        header: {
          "Content-Type": "applqciation/json"
        },
        data: {
          databaseindex: that.data.swipers[that.data.currentindex].index
        },
        success: function (res) {
          console.log(res.data);
          that.setData({
            content: res.data
          })
        }
      })
    }else if(that.data.currentindex==0&&app.globalData.openId!=''){
      wx.request({
        url: app.globalData.requesturl + 'content/gethot',
        header: {
          'content-type': 'application/json'

        },
        data: {
          user_id: app.globalData.openId
        },
        success: function (res) {
          that.setData({
            content0: res.data
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that=this;
    console.log("openid=" + app.globalData.openId);
    this.setData({
      cardindex: -1,
    })
    var that = this;

    if (app.globalData.openId != '') {
      wx.request({
        url: app.globalData.requesturl + 'login/getFunction',
        method: 'get',
        header: {
          'content-type': 'application/json'

        },
        data: {
          openid: app.globalData.openId
        },
        success: function (res) {
          //设置swipers
          console.log("function=" + res.data);
          var con = res.data.split("-");
          var nums = parseInt(res.data.length / 2 + 1);
          var temp = new Array(nums + 1);
          var obj = {
            name: "推荐",
            index: 10
          };
          temp[0] = obj;
          for (var i = 0; i < con.length; ++i) {
            console.log(con[i])
            var t = {
              name: that.data.database[con[i]].name,
              index: con[i]
            };
            temp[i + 1] = t;
          }
          console.log(temp);
          that.setData({
            swipers: temp
          });
        }
      }); 
    }
    that.updata();
    

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})