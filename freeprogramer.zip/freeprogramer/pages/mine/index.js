// pages/mine/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    openId: '',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    itemtexts: ['我的分类', '发表文章', '匿名论坛', '我的文章', '收藏', '意见反馈'],
    imageurl: ['../../assets/fenlei.png', '../../assets/wenzhang.png', '../../assets/plun.png', '../../assets/mine.png', '../../assets/shoucang.png', '../../assets/fankui.png']
  },

  taplist: function (e) {
    if(app.globalData.userInfo==null){
      wx.showToast({
        title: '未登录,不可用',
        icon:'none'
      })
      return;
    }
    var index = e.currentTarget.dataset.index;
    if (index == 0) {
      wx.navigateTo({
        url: '../itemMannage/index',
      })
    } else if (index == 1) {
      wx.navigateTo({
        url: '../up/index',
      })
    } else if (index == 2) {
      wx.navigateTo({
        url: '../uplun/index',
      })
    } else if (index == 3) {
      wx.navigateTo({
        url: '../mycontent/index',
      })
    } else if (index == 4) {
      wx.navigateTo({
        url: '../collection/index',
      })
    } else {
      wx.navigateTo({
        url: '../advice/index',
      })
      s
    }

  },

  getUserInfo: function (e) {
    var that = this;
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo;

    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
    wx.getSetting({
      success: res => {

        // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
        wx.getUserInfo({
          success: res => {
            // 可以将 res 发送给后台解码出 unionId
            app.globalData.userInfo = res.userInfo;
            console.log("wx.getSetting")
            console.log(res.encryptedData);
            console.log(res.iv);
            wx.request({
              url: app.globalData.requesturl+'login/regist', //自己的服务接口地址
              method: 'get',
              header: {
                "Content-Type": "applqciation/json"
              },
              data: {
                encryptedData: res.encryptedData,
                iv: res.iv,
                code: app.globalData.code
              },
              success: function (res) {

                //4.解密成功后 获取自己服务器返回的结果
                if (res.statusCode == 200) {
                  if (res.data != null)
                    that.setData({
                      openId: res.data,
                    })
                  console.log(that.data.openId)
                  that.setglobalData();
                } else {
                  console.log('[INFO] app.js/ 解密失败')
                }
              },
              fail: function () {
                console.log('[INFO] app.js/ 系统错误')
              }
            });

            app.globalData.userInfo = res.userInfo
            // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
            // 所以此处加入 callback 以防止这种情况
            if (app.userInfoReadyCallback) {
              app.userInfoReadyCallback(res)
            }
          }
        })

      }
    })

  },

  setglobalData: function (e) {
    app.globalData.openId=this.data.openId;
    console.log(app.globalData.openId);
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })

      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})