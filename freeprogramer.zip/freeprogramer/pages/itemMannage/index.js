// pages/itemMannage/index.js
var app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    con: [{
        id: 0,
        name: 'code',
        checked: true
      },
      {
        id: 1,
        name: '计算机基础',
        checked: true
      },
      {
        id: 2,
        name: '前端',
        checked: true
      },
      {
        id: 3,
        name: 'java',
        checked: true
      },
      {
        id: 4,
        name: 'java框架',
        checked: false
      },
      {
        id: 5,
        name: '数据库',
        checked: false
      },
      {
        id:6,
        name: 'C语言',
        checked: false
      },
      {
        id: 7,
        name: 'C++',
        checked: false
      },
      {
        id: 8,
        name: 'sql编程',
        checked: false
      }
    ],
  },


  submit: function (e) {

    var j = 0;
    for (var i = 0; i < 9; ++i) {
      if (this.data.con[i].checked == true)
        ++j;
    }
    if (j > 4) {
      wx.showToast({
        title: '最多选择4个分类',
      })
      return;
    }
    var functionstr='';
    for(var i=0;i<9;++i){
      if(this.data.con[i].checked==true){
        functionstr+=this.data.con[i].id;
        if(i<j-1)
        functionstr+='-';
      }

    }
    wx.request({
      url: app.globalData.requesturl+'login/upmyfunction',
      method: 'get',
      header: {
        "Content-Type": "applqciation/json"
      },
      data:{
        functionstr:functionstr,
        user_id:app.globalData.openId
      }
    })
  },
  checkboxchange(e) {

 

    var tcon = e.detail.value;
    var con = this.data.con;
    var l = e.detail.value.length;
    for (var i = 0; i < 9; ++i) {
      con[i].checked = false;
    }
    if (e.detail.value.length > 4) {
      wx.showToast({
        title: '最多只能选择四个',
        icon:'none'
      })
      l--;
    }
    for (var i = 0; i < l; ++i) {
      con[tcon[i]].checked = true;
    }
    this.setData({
      con: con,
    })
    console.log(this.data.con);

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})