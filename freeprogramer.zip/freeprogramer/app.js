//app.js
App({


  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
    var app = this;
    // 登录
  
  

  },
  globalData: {
    requesturl:'http://192.168.0.106:8888/freeprogram/',
    userInfo: null,
    code: '',
    openId:'',
  }
})